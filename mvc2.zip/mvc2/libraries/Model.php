<?php

include 'DB.php';

class Model extends DB{

	public $result;

	public function __construct(){

		parent::__construct();
	}

	public function query($sql){
		//echo $sql;
		$this->result = mysqli_query($this->conn,$sql);
		if($this->result)
			return true;
		else
			return false;

	}

	public function num_rows(){
		//var_dump($this->result);exit;
		return mysqli_num_rows($this->result);
	}

	public function row(){
		
		return mysqli_fetch_assoc($this->result);
	}

	public function rows(){
		$rows = array();

		while($row = mysqli_fetch_assoc($this->result)){
			$rows[]= $row;
		}
		return $rows;
	}
}