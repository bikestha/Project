<?php

include 'config.php';

class DB{

	protected $conn;

	public function __construct(){
		$this->conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_DBNAME);
		if(!$this->conn){
			die('Connection Error');
		}
	}
}