<?php
include 'Request.php';

class Router{

	public $request; 

	public function __construct(){
		
		$this->request = new Request;
		//var_dump($request);
	}

	public function get($uri,$clouser){
		
		if( $_SERVER['REQUEST_METHOD'] =='GET'){

			preg_match('/\.php.*/', $this->request->url, $matches);
			//echo $matches[0];
			
			$matchUri = '.php/'.$uri;

			if( $matchUri == $matches[0]){  //.php/login === .php/login
				
				$class = ucfirst($uri).'Controller';  // LoginController
				include 'controllers/'.$class.'.php';
				call_user_func($clouser);
			}
		}

		//var_dump($matches);

		
		

	}

	public function post($uri,$clouser){
		
		if( $_SERVER['REQUEST_METHOD'] =='POST'){
		
			preg_match('/\.php.*/', $this->request->url, $matches);
			
			$matchUri = '.php/'.$uri;

			if( $matchUri == $matches[0]){  //.php/login === .php/login
				
				$class = ucfirst($uri).'Controller';  // LoginController
				include 'controllers/'.$class.'.php';
				call_user_func($clouser);
			}
		}

	}


}