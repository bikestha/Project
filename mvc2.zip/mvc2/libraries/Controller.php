<?php
 class Controller{

 	public $model;

 	public function __construct($modelprefx){

 		$modelname = ucfirst($modelprefx).'Model';  //LoginModel
 		$path = 'models/'.$modelname.'.php';
 		if( file_exists($path)){
 			include ( $path);
 			$this->model = new $modelname(); //new LoginModel
		}

 	}

 	public function view($view,$data=null){

 		$path = 'views/'.$view.'.php';

 	 
 		if(file_exists($path)){
 			if($data){
 				extract($data);
 			}
 			include($path);
 		}

 	}

 	public function redirect($path){

 		header('Location: '. $path);
 	}

 }