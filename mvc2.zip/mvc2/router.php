<?php

$router = new Router;

$router->get('login',function(){

	$obj = new LoginController();
	$obj->index();

});


$router->post('login',function(){

	$obj = new LoginController();
	$obj->process();

});

$router->get('list',function(){
	$obj = new ListController();
	$obj->index();
});

$router->get('post',function(){
	$obj = new PostController();
	$obj->form();
});

$router->post('post',function(){
	$obj = new PostController();
	$obj->save();
});