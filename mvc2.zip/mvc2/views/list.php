<?php include 'header.php';?>

<h2>Post List</h2>
<div style="float: right;">
	<a href="post" class="btn btn-primary">New Post</a>
</div>
<table class="table">
		<thead>
			<tr>
				<th>S.N</th>
				<th>Title</th>
				<th>Image</th>
				<th>Description</th>
				<th>Author</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			
			<?php foreach ($posts as $key => $value) {?>
			<tr>
				<td><?php echo $key+1;?></td>
				<td><?php echo $value['title'];?></td>
				<td><img src="uploads/<?php echo $value['images'];?>"></td>
				<td><?php echo $value['description'];?></td>
				<td><?php echo $value['user_id'];?></td>
				<td>Edit | Delete</td>
				</tr>
			<?php } ?>
			
				
			
		</tbody>
</table>
<?php include 'footer.php';?>