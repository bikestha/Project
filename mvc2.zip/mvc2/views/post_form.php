<?php include 'header.php';?>
<form class="form-horizontal" method="post" action="" enctype="multipart/form-data">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Title</label>
    <div class="col-sm-10">
      <input name="title" type="text" class="form-control" id="inputEmail3" placeholder="Title">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Description</label>
    <div class="col-sm-10">
      <textarea name="description" class="form-control" id="inputPassword3" placeholder="Description" rows="20" cols="40"></textarea>
    </div>
  </div>

  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Image</label>
    <div class="col-sm-10">
     <input type="file" name="image">
    </div>
  </div>
 	

  <div class="form-group">
    <label class="col-sm-2 control-label">Publish</label>
    <input type="radio" name="publish" value="1" checked> Yes
    <input type="radio" name="publish" value="0"> No
  </div>
  	
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Post</button>
    </div>
  </div>
</form>
<?php include 'footer.php';?>