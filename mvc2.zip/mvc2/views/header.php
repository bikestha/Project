<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="../css/bootstrap.min.css">


		<!-- Latest compiled and minified JavaScript -->
		<script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">