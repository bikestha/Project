<?php include 'header.php';?>

	
<h2>Login</h2>
	<?php if( isset($_GET['error']) && $_GET['error']==1 ) {?>
	<div class="alert alert-danger">Invalid email or password.</div>
	<?php }?>	
  <form name="loginform" action="" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="text" class="form-control" id="email"  name="email" placeholder="Email">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
  </div>
  
  <div class="checkbox">
    <label>
      <input type="checkbox" name="loggedin" value="1"> Keep me Loggedin
    </label>
  </div>

  <a href="register.php">SignUp</a>
  <button type="submit" class="btn btn-default">Submit</button>
</form>

<?php include 'footer.php';?>