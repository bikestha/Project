<?php
class ListModel extends Model{

	public function getList(){

		$sql = "SELECT * FROM tbl_posts";
		$this->query($sql);
		return $this->rows();
	}
}