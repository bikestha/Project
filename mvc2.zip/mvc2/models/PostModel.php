<?php 
class PostModel extends Model{
	
	public function savePost($data = array()){

		$title = $data['title'];
		$description = $data['description'];
		$image = $data['image'];
		$user_id = $_SESSION['user']['id'];
		$publish =$data['publish'];

		$sql= "INSERT INTO tbl_posts(title,description,image,user_id,publish)
		VALUES ('$title','$description','$image','$user_id','$publish')
		";
		if( $this->query($sql) ) 
			return true;
		else
			return false;

	}
}