<?php

class LoginModel extends Model{


	public function checkUser($email, $password){

		$password = md5($password);
		$sql = "SELECT * FROM tbl_users WHERE 
		email='$email' AND password='$password'
		";	
		$this->query($sql);
		if( $this->num_rows()){
			return $this->row();
		}else{
			return false;
		}

	}
}