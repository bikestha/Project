<?php 
session_start();
include 'libraries/Router.php';
include 'libraries/Controller.php';
include 'libraries/Model.php';
include 'router.php';
include 'vendor/autoload.php';
use \Eventviva\ImageResize;
