<?php 

class PostController extends Controller{
	public function __construct(){

		parent::__construct('post');
	}

	public function form(){
		$this->view('post_form');
	}

	public function save(){
		$post = array();
		$post['title'] = $_POST['title'];
		$post['description'] = $_POST['description'];
		$post['publish'] = $_POST['publish'];
		$image = $_FILES['image'];
		if($image['error']==0){
		
			$fileparts = explode('.',$image['name']);
			
			$extension = array_pop($fileparts);

			$newfile = time().date('Y-m-d'); 
			$thumbnail = $newfile.'_thumb'.$extension;
			$newfile = $newfile.'.'.$extension;
			move_uploaded_file($image['tmp_name'], 'uploads/'.$newfile);
			$post['image'] = $newfile;

			$filePath = 'uploads/'.$newfile;
			$image = new ImageResize($filePath);
			$image->scale(50);
			$image->save('uploads/'.$thumbnail);

		}

		if( $this->model->savePost($post) ){
			$this->redirect('list');
		}else{
			$this->redirect('post');
		}

	}
}