<?php
class ListController extends Controller{

	public function __construct(){

		parent::__construct('list');
	}

	public function index(){
		$results = $this->model->getList();

		//echo '<pre>';
		//print_r($results );

		$this->view('list', array( 'posts' =>$results));
	}


}