<?php 

class PostsController  extends Controller{
	
	public function __construct(){

		parent::__construct('posts');
		
		//echo 'I am PostContorller';
	}
}