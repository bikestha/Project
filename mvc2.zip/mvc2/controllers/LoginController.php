<?php
class LoginController extends Controller{

	public $model;

	public function __construct(){

		parent::__construct('login');
		
		//$this->model = new LoginModel();
		//echo 'I am LoginController';
	}


	public function index(){

		$this->view('login');
	}


	public function process(){

		$email = $_POST['email'];
		$password = $_POST['password'];

		$result= $this->model->checkUser($email, $password);
		//var_dump($result);exit;
		if($result){

			$_SESSION['loggedin'] = true;
			$_SESSION['user'] = $result;
			$this->redirect('list');

		// has user
		}else{ // No user

			$this->redirect('login');
		}
		//var_dump($_POST);
	}
}